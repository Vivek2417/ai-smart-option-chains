# AI Smart Option Chains

A simple Next.js app that displays AI-generated options chain insights.

## Install Dependencies
```bash
npm install
