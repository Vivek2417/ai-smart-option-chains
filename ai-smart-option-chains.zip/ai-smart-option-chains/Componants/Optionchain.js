import React, { useEffect, useState } from "react";
import { fetchOptionsChain } from "@/utils/api";
import { TrendingUp, AlertCircle } from "lucide-react";

const OptionChains = () => {
  const [optionsData, setOptionsData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadData() {
      try {
        const data = await fetchOptionsChain();
        setOptionsData(data);
      } catch (err) {
        setError("Failed to load data");
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  if (loading) return <p>Loading options data...</p>;
  if (error) return <p className="text-red-500">{error}</p>;

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">AI-Generated Smart Option Chains</h2>
      <div className="border rounded-lg p-4">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-2 border">Strike Price</th>
              <th className="p-2 border">IV Rank</th>
              <th className="p-2 border">OI Change</th>
              <th className="p-2 border">AI Insights</th>
            </tr>
          </thead>
          <tbody>
            {optionsData.length > 0 ? (
              optionsData.map((option, index) => (
                <tr key={index} className="text-center border-b">
                  <td className="p-2 border">{option.strike}</td>
                  <td className="p-2 border">{option.ivRank}%</td>
                  <td className="p-2 border">{option.oiChange > 0 ? `+${option.oiChange}` : option.oiChange}</td>
                  <td className="p-2 border">
                    {option.aiSignal === "BUY" ? (
                      <span className="text-green-600 flex items-center justify-center">
                        <TrendingUp className="w-4 h-4 mr-2" /> Bullish
                      </span>
                    ) : (
                      <span className="text-red-600 flex items-center justify-center">
                        <AlertCircle className="w-4 h-4 mr-2" /> Bearish
                      </span>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" className="text-gray-500 p-4">No data available</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default OptionChains;
